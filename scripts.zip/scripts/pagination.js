function setupPagination(articlesToPaginate) {
    const itemsPerPage = 5;
    const totalPages = Math.ceil(articlesToPaginate.length / itemsPerPage);
    const paginationContainer = document.getElementById('pagination');
    paginationContainer.innerHTML = '';

    for (let i = 1; i <= totalPages; i++) {
        const pageButton = document.createElement('button');
        pageButton.textContent = i;

        pageButton.addEventListener('click', () => {
            const start = (i - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            displayArticles([...articlesToPaginate].reverse().slice(start, end), 'all-articles');

            document.querySelectorAll('#pagination button').forEach(btn => btn.classList.remove('active'));
            pageButton.classList.add('active');
        });

        paginationContainer.appendChild(pageButton);
    }

    // Tampilkan halaman pertama
    if (articlesToPaginate.length > 0) {
        displayArticles([...articlesToPaginate].reverse().slice(0, itemsPerPage), 'all-articles');
        paginationContainer.querySelector('button')?.classList.add('active');
    }
}
