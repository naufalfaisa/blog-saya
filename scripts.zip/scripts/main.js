document.addEventListener('DOMContentLoaded', function () {
    // Navigasi antar halaman
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo(link.dataset.page);
        });
    });

    // Fitur pencarian
    document.getElementById('search-button')?.addEventListener('click', searchArticles);
    document.getElementById('search-input')?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchArticles();
    });

    // Inisialisasi fitur
    renderArticles(articles);      // tampil semua artikel
    setupPagination(articles);     // pagination awal
    setupCategoryFilter();         // filter kategori
    setupArchiveFilter();          // filter arsip
    setupContactForm();            // kirim form
    setupProfileImageReload();     // fitur ganti gambar profil
    setupLazyImages();             // lazy loading gambar

    // Tampilkan halaman home
    navigateTo('home');
});
